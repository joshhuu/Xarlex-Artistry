"use client"

import type React from "react"
import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Loader2, Sparkles, X, Zap, Palette, ImageIcon, Sun, Moon } from "lucide-react"
import Image from "next/image"

export default function Home() {
  const [prompt, setPrompt] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedImage, setGeneratedImage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [showBanner, setShowBanner] = useState(true)
  const [isDarkMode, setIsDarkMode] = useState(false)
  const generatorRef = useRef<HTMLDivElement>(null)

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode)
  }

  const scrollToGenerator = () => {
    generatorRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const generateImage = async () => {
    if (!prompt.trim()) return

    setIsGenerating(true)
    setError(null)
    setGeneratedImage(null)

    try {
      const response = await fetch("/api/generate-image", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ prompt }),
      })

      if (!response.ok) {
        throw new Error("Failed to generate image")
      }

      const data = await response.json()
      setGeneratedImage(data.imageUrl)
    } catch (err) {
      setError("Failed to generate image. Please try again.")
      console.error("Error generating image:", err)
    } finally {
      setIsGenerating(false)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !isGenerating) {
      generateImage()
    }
  }

  return (
    <div className={`min-h-screen transition-colors duration-300 ${isDarkMode ? "bg-gray-900" : "bg-gray-50"}`}>
      {/* Top Banner */}
      {showBanner && (
        <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-4 py-3 text-center relative">
          <div className="flex items-center justify-center gap-2">
            <Zap className="w-4 h-4" />
            <span className="text-sm font-medium">
              Completely Free! No login or signup required. Start creating instantly!
            </span>
          </div>
          <button
            onClick={() => setShowBanner(false)}
            className="absolute right-4 top-1/2 transform -translate-y-1/2 text-white/80 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Header */}
      <header
        className={`border-b px-4 py-4 transition-colors duration-300 ${isDarkMode ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"}`}
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
              <Palette className="w-5 h-5 text-white" />
            </div>
            <span
              className={`text-xl font-bold transition-colors duration-300 ${isDarkMode ? "text-white" : "text-gray-900"}`}
            >
              AI Art Studio
            </span>
          </div>

          <div className="hidden md:block">
            <button
              onClick={toggleDarkMode}
              className={`p-2 rounded-lg transition-colors duration-300 ${isDarkMode ? "bg-gray-700 text-yellow-400 hover:bg-gray-600" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}
            >
              {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={toggleDarkMode}
              className={`md:hidden p-2 rounded-lg transition-colors duration-300 ${isDarkMode ? "bg-gray-700 text-yellow-400 hover:bg-gray-600" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}
            >
              {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
            <Button
              onClick={scrollToGenerator}
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-6 py-2 rounded-lg font-medium"
            >
              Get Started
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="px-4 py-20 text-center">
        <div className="max-w-4xl mx-auto">
          <Badge
            variant="secondary"
            className={`mb-8 px-4 py-2 text-sm font-medium transition-colors duration-300 ${isDarkMode ? "bg-purple-900/30 text-purple-300 border-purple-700" : "bg-purple-100 text-purple-700 border-purple-200"}`}
          >
            <Sparkles className="w-4 h-4 mr-2" />
            AI-Powered • 100% Free • No Signup Required
          </Badge>

          <h1
            className={`text-5xl md:text-7xl font-black mb-6 leading-tight transition-colors duration-300 ${isDarkMode ? "text-white" : "text-gray-900"}`}
          >
            Create{" "}
            <span className="bg-gradient-to-r from-purple-600 via-blue-600 to-purple-600 bg-clip-text text-transparent">
              Stunning
            </span>
            <br />
            <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
              AI Artwork
            </span>
          </h1>

          <p
            className={`text-xl mb-12 max-w-2xl mx-auto leading-relaxed transition-colors duration-300 ${isDarkMode ? "text-gray-300" : "text-gray-600"}`}
          >
            Transform your ideas into professional AI artwork in seconds with our FLUX.1-dev powered platform. No design
            skills needed, no signup required.
          </p>

          <div className="flex justify-center">
            <Button
              onClick={scrollToGenerator}
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8 py-4 rounded-xl font-semibold text-lg shadow-lg hover:shadow-xl transition-all duration-300"
            >
              Start Creating Now
              <Sparkles className="ml-2 w-5 h-5" />
            </Button>
          </div>
        </div>
      </section>

      {/* Generator Section */}
      <section
        ref={generatorRef}
        className={`px-4 py-20 transition-colors duration-300 ${isDarkMode ? "bg-gray-800" : "bg-white"}`}
      >
        <div className="max-w-4xl mx-auto text-center mb-12">
          <h2
            className={`text-4xl md:text-5xl font-bold mb-6 transition-colors duration-300 ${isDarkMode ? "text-white" : "text-gray-900"}`}
          >
            Visualize{" "}
            <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              Your Vision
            </span>
          </h2>
          <p
            className={`text-xl max-w-2xl mx-auto transition-colors duration-300 ${isDarkMode ? "text-gray-300" : "text-gray-600"}`}
          >
            Experience the seamless creation process with our intuitive AI dashboard. Scroll to explore.
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          <Card
            className={`shadow-xl rounded-2xl p-8 md:p-12 transition-colors duration-300 ${isDarkMode ? "bg-gray-700 border-gray-600" : "bg-white border-gray-200"}`}
          >
            <div className="space-y-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <ImageIcon className="w-8 h-8 text-white" />
                </div>
                <h3
                  className={`text-2xl font-bold mb-2 transition-colors duration-300 ${isDarkMode ? "text-white" : "text-gray-900"}`}
                >
                  AI Art Generator
                </h3>
                <p className={`transition-colors duration-300 ${isDarkMode ? "text-gray-300" : "text-gray-600"}`}>
                  Describe your vision and watch it come to life
                </p>
              </div>

              <div className="space-y-6">
                <div className="relative">
                  <Input
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="A majestic dragon soaring through a neon-lit cyberpunk city..."
                    className={`w-full px-6 py-4 text-lg border-2 rounded-xl focus:border-purple-400 focus:ring-purple-400/20 transition-all duration-300 ${isDarkMode ? "bg-gray-600 border-gray-500 text-white placeholder-gray-400" : "border-gray-200 placeholder-gray-400"}`}
                    disabled={isGenerating}
                  />
                </div>

                <Button
                  onClick={generateImage}
                  disabled={isGenerating || !prompt.trim()}
                  className="w-full py-4 text-lg font-semibold bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isGenerating ? (
                    <div className="flex items-center justify-center">
                      <Loader2 className="w-6 h-6 animate-spin mr-3" />
                      <span>Creating magic...</span>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center">
                      <Sparkles className="w-6 h-6 mr-3" />
                      <span>Generate Artwork</span>
                    </div>
                  )}
                </Button>

                {error && (
                  <div
                    className={`text-center p-4 border rounded-xl transition-colors duration-300 ${isDarkMode ? "bg-red-900/20 border-red-700" : "bg-red-50 border-red-200"}`}
                  >
                    <p
                      className={`font-medium transition-colors duration-300 ${isDarkMode ? "text-red-400" : "text-red-600"}`}
                    >
                      {error}
                    </p>
                  </div>
                )}

                {isGenerating && (
                  <div className="flex justify-center items-center py-12">
                    <div className="flex space-x-2">
                      <div
                        className="w-3 h-3 bg-purple-500 rounded-full animate-bounce"
                        style={{ animationDelay: "0ms" }}
                      />
                      <div
                        className="w-3 h-3 bg-blue-500 rounded-full animate-bounce"
                        style={{ animationDelay: "150ms" }}
                      />
                      <div
                        className="w-3 h-3 bg-purple-500 rounded-full animate-bounce"
                        style={{ animationDelay: "300ms" }}
                      />
                    </div>
                  </div>
                )}

                {generatedImage && (
                  <div className="animate-fade-in-up">
                    <div
                      className={`relative rounded-2xl overflow-hidden shadow-2xl border transition-colors duration-300 ${isDarkMode ? "border-gray-600" : "border-gray-200"}`}
                    >
                      <Image
                        src={generatedImage || "/placeholder.svg"}
                        alt="Generated AI artwork"
                        width={800}
                        height={800}
                        className="w-full h-auto object-cover"
                        crossOrigin="anonymous"
                      />
                    </div>
                    <div
                      className={`text-center mt-6 p-4 rounded-xl border transition-colors duration-300 ${isDarkMode ? "bg-purple-900/20 border-purple-700" : "bg-gradient-to-r from-purple-50 to-blue-50 border-purple-100"}`}
                    >
                      <p
                        className={`font-medium transition-colors duration-300 ${isDarkMode ? "text-purple-300" : "text-purple-700"}`}
                      >
                        ✨ Your AI masterpiece is ready!
                      </p>
                      <p
                        className={`text-sm mt-1 transition-colors duration-300 ${isDarkMode ? "text-purple-400" : "text-purple-600"}`}
                      >
                        Right-click to save your artwork
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* Features Section */}
      <section className={`px-4 py-20 transition-colors duration-300 ${isDarkMode ? "bg-gray-900" : "bg-gray-50"}`}>
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2
              className={`text-4xl font-bold mb-4 transition-colors duration-300 ${isDarkMode ? "text-white" : "text-gray-900"}`}
            >
              Why Choose AI Art Studio?
            </h2>
            <p className={`text-xl transition-colors duration-300 ${isDarkMode ? "text-gray-300" : "text-gray-600"}`}>
              Everything you need to create stunning AI artwork
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div
              className={`text-center p-8 rounded-2xl shadow-lg border transition-colors duration-300 ${isDarkMode ? "bg-gray-800 border-gray-700" : "bg-white border-gray-100"}`}
            >
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Zap className="w-8 h-8 text-white" />
              </div>
              <h3
                className={`text-xl font-bold mb-4 transition-colors duration-300 ${isDarkMode ? "text-white" : "text-gray-900"}`}
              >
                Lightning Fast
              </h3>
              <p className={`transition-colors duration-300 ${isDarkMode ? "text-gray-300" : "text-gray-600"}`}>
                Generate high-quality artwork in seconds with our optimized FLUX.1-dev model
              </p>
            </div>

            <div
              className={`text-center p-8 rounded-2xl shadow-lg border transition-colors duration-300 ${isDarkMode ? "bg-gray-800 border-gray-700" : "bg-white border-gray-100"}`}
            >
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Sparkles className="w-8 h-8 text-white" />
              </div>
              <h3
                className={`text-xl font-bold mb-4 transition-colors duration-300 ${isDarkMode ? "text-white" : "text-gray-900"}`}
              >
                100% Free
              </h3>
              <p className={`transition-colors duration-300 ${isDarkMode ? "text-gray-300" : "text-gray-600"}`}>
                No hidden costs, no subscriptions. Create unlimited artwork completely free
              </p>
            </div>

            <div
              className={`text-center p-8 rounded-2xl shadow-lg border transition-colors duration-300 ${isDarkMode ? "bg-gray-800 border-gray-700" : "bg-white border-gray-100"}`}
            >
              <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <ImageIcon className="w-8 h-8 text-white" />
              </div>
              <h3
                className={`text-xl font-bold mb-4 transition-colors duration-300 ${isDarkMode ? "text-white" : "text-gray-900"}`}
              >
                No Signup Required
              </h3>
              <p className={`transition-colors duration-300 ${isDarkMode ? "text-gray-300" : "text-gray-600"}`}>
                Start creating immediately. No accounts, no personal data, complete privacy
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
